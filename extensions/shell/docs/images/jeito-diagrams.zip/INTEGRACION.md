# Diagramas para Rooklight Shell

El paquete incluye tres SVG editables, sus versiones PNG a doble resolución y el README con los diagramas insertados.

## Uso directo

Coloca `README.md` y la carpeta `docs/assets/` de este paquete en el directorio del README de la extensión. Las rutas de las imágenes son relativas a ese directorio. Los enlaces que ya tenía el README se han conservado y dependen del resto de tu repositorio.

El README conserva el texto original: añade dos imágenes, sustituye el bloque de cronología ASCII por la tercera y elimina las dos líneas finales de `zed is already running`.

| Diagrama | Archivo | Ubicación en el README |
| --- | --- | --- |
| 01 · Start once. Stay in control. | `docs/assets/rooklight-jobs.svg` | Después de la introducción. |
| 02 · Keep work moving. | `docs/assets/rooklight-execution.svg` | Sustituye el bloque ASCII de «Keep work moving». |
| 03 · Less noise. Evidence within reach. | `docs/assets/rooklight-context.svg` | Después del párrafo que presenta LeanCTX. |

## Solo las imágenes

Si prefieres integrar los diagramas en tu versión actual, copia `docs/assets/` junto al README y pega cada línea en su ubicación:

```markdown
![A bounded wait returns either a result or control of a managed job that can be inspected, waited on, or stopped.](docs/assets/rooklight-jobs.svg)

![Independent work overlaps the running command after the initial wait. Command duration is unchanged; timings are illustrative.](docs/assets/rooklight-execution.svg)

![LeanCTX output is captured in a session log and selected into bounded views. Details removed during compression cannot be recovered.](docs/assets/rooklight-context.svg)
```

Para usar las copias PNG, cambia `.svg` por `.png`. El fondo oscuro está incluido en cada archivo. Los SVG contienen texto editable, título y descripción accesibles; no requieren fuentes externas, JavaScript ni imágenes enlazadas. Las fuentes de sustitución pueden producir pequeñas diferencias tipográficas. Los PNG fijan el aspecto exacto de las previsualizaciones.

## Criterios de contenido

- La cronología representa un orden ilustrativo; no presenta tiempos medidos ni una aceleración del comando.
- El log conserva la salida del tratamiento elegido. No recupera información eliminada por LeanCTX.
- La captura sin compresión debe elegirse antes de ejecutar cuando se necesita la salida exacta.
- Los trabajos y los logs pertenecen a la sesión. La notificación de finalización no sustituye la inspección del agente.

Los diagramas se basan en el README facilitado; no constituyen una auditoría del código ni una validación de sus declaraciones de compatibilidad.
