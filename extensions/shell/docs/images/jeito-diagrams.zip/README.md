---
title: "Rooklight Shell — compact, recoverable command execution"
description: "Useful command output without flooding each turn: LeanCTX handling, recoverable bounded views, reusable scripts, and background jobs for Pi."
tags: [rooklight, shell, bash, jobs, leanctx]
created: 2026-07-26
updated: 2026-09-19
status: pre-release
owns: "The approachable Rooklight Shell package entrypoint"
audience: mixed
related: [THIRD_PARTY_NOTICES.md]
---

# Rooklight Shell

Rooklight Shell keeps slow commands and large outputs from unnecessarily consuming an agent's working time and context. Long-running work automatically becomes available for background monitoring instead of keeping the agent waiting for completion. The agent can continue independent work, inspect progress and return to the result when it is needed. Combined with command-aware output reduction and searchable logs, this gives the agent more control over where it spends time and attention.

![A command waits for a bounded time, then either returns its result or continues as the same managed job. The agent can inspect output, wait again, or stop the run.](docs/assets/rooklight-jobs.svg)

## Keep work moving

Pi's built-in command execution, inspected in version 0.84.3, waits for the command to finish and has no default timeout. An optional timeout can stop the process, but it cannot decide whether the work is slow, stuck or still useful. Without a limit, one unfinished command can hold up the agent's next decision; with a termination limit, useful work can be cut short and need to run again.

Shell bounds the wait without aborting the work. A command that takes longer than the initial wait keeps running under the same management, with its progress and output available for inspection. This does not depend on the agent predicting the duration correctly before starting. The agent regains the opportunity to decide whether to wait longer, continue another part of the task, or stop work that is no longer useful.

Background execution is useful only when the agent can still follow and control the work. Shell keeps that responsibility inside the session:

| What gets in the way | What Shell changes | Why it matters |
| --- | --- | --- |
| A slow command holds up the next decision. | Returns control while the command continues. | Independent work can proceed without canceling progress. |
| Backgrounding leaves process tracking and output collection to the caller. | Keeps running state, output and completion together. | The agent can inspect the existing run instead of reconstructing its status or starting another. |
| Fixed sleeps delay checking a result that may already be ready. | A further wait ends on completion or when its waiting period ends. | The agent can wait for the actual work rather than repeatedly guessing when to check. |
| Progress checks repeat output already seen. | Offers new or selected output while retaining the captured log. | Monitoring need not fill the conversation with the same text again. |

The opportunity is to overlap independent work, not make an individual command execute faster:

![Illustrative timelines with the same command duration. A bounded initial wait lets independent work overlap the running command, followed by an explicit result inspection.](docs/assets/rooklight-execution.svg)

Illustrative ordering, not measured timings. The command keeps its running time; independent work no longer has to come afterward. Inspection remains an explicit agent action.

Parallel work still needs correct dependencies. The agent must wait when it needs a result, and must not change files that a running check relies on. Completion notices inform the user but do not automatically make the agent resume or verify the outcome.

## Use context for relevant evidence

Builds, tests and other commands often produce far more text than an agent needs to understand the result. Carrying that output through the conversation spends limited context on routine information. Simply cutting it off creates a different problem: the explanation of a failure may be in the part the agent never sees.

Shell uses [LeanCTX](https://github.com/yvgude/lean-ctx) to reduce output according to the command that produced it. This matters because a single generic cutoff cannot distinguish routine command noise from information that must remain unchanged. LeanCTX supplies command-aware compression, protected output and passthrough; Shell integrates those choices with retained logs and ongoing process monitoring.

![Command output passes through LeanCTX into a retained session log, from which bounded views select new, matching, or recent output. Details removed by LeanCTX cannot be recovered; exact output requires choosing uncompressed capture before execution.](docs/assets/rooklight-context.svg)

Repeated progress checks need not repeatedly send the same log to the model. The agent can inspect new output, focus on matching lines or read a recent portion, while the captured log remains available for deeper investigation. This reduces avoidable repetition during monitoring and lets the agent request detail for a specific question instead of loading everything in advance.

Retaining the captured output also avoids rerunning a command just because its first response omitted a needed detail. A rerun costs more work and may produce different evidence. Pi already saves oversized output; Shell combines that recoverability with output reduction and selective checks throughout the command's lifetime. The result is a way to spend context on the evidence currently needed without making every short response a dead end.

Compression and recoverability have different limits. The saved log contains what LeanCTX produced, not details it removed. Uncompressed capture must be selected before execution when exact output is needed. Both forms combine normal and error output. Smaller responses reduce what is presented at each inspection; total context use still depends on how much the agent subsequently reads.

## Session limits

Running commands and saved output belong to the current session, not a durable queue that survives restarting Pi. Multiline commands can be retained and rerun within that session, avoiding repeated reconstruction of the same command; lasting scripts belong in project files.

Incremental output checks move past everything captured so far, including text omitted from the displayed result. Omitted text must be recovered from the saved log, not from the next incremental check. Logs and temporary scripts live under `/tmp/rooklight-shell` and are removed at session shutdown. They may contain sensitive information. Shell neither removes secrets from output nor isolates commands from the rest of the computer.

## Install from a checkout

Requirements:

- Node.js 22.19.0 or newer, npm, and Pi satisfying the declared `@earendil-works/pi-coding-agent >=0.82.1` peer dependency.
- macOS or Linux on ARM64 or x64; Linux GNU and musl runtime artifacts are provided. Windows is not supported by the runtime selector.
- Bash for execution, `tar` for runtime extraction, and network access to the LeanCTX GitHub release during initial preparation. Shell needs no API key.

These are the [package declarations](package.json) and [runtime targets](lean-ctx-runtime.mjs), not a tested compatibility matrix.

```bash
cd /absolute/path/to/rooklight
npm install --omit=dev \
  --workspace @alehdezp/rooklight-shell \
  --include-workspace-root=false
# Continue only if npm succeeded:
pi install "$PWD/extensions/shell"
```

Keep the checkout at the registered path and restart Pi. Do not register this package beside an aggregate or another extension that already supplies the same command execution and job controls. Pi local-path registration does not prepare dependencies, and Pi Git sources cannot select a monorepo subdirectory. See [installation and updates](../../docs/getting-started.md) for the shared workflow. Standalone installation does not apply host-owned prompt or tool-routing defaults.

### LeanCTX installation

npm `postinstall` downloads LeanCTX 3.9.12, checks the archive against its pinned SHA-256 checksum before extraction, and checks the version before marking `.runtime/` ready. Startup checks the runtime's identity, whether it can execute, and its binary hash before making the tools available. It does not download or repair anything.

LeanCTX config, data, state and cache paths stay under the extension's ignored `.runtime/`. This integration does not alter global `PATH`, shell startup files, or an existing LeanCTX installation. If startup reports a missing or altered runtime, stop Pi, run `npm run setup:lean-ctx` from the extension directory, and restart Pi after successful preparation.

Compression is upstream LeanCTX work; the shell-only integration adapts `pi-lean-ctx`. Attribution, Apache 2.0 notices for LeanCTX, and the integration boundary are in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## Tests

The tests substitute Bash for LeanCTX and use local archives for installation checks. They cover how Shell runs commands and records their output, but do not test real compression quality or installation over the network.

Do not run the tests alongside live Shell sessions sharing `/tmp/rooklight-shell`: test shutdown removes scripts from the shared temporary directory. In an isolated environment with no such sessions, run from the repository root:

```bash
npm test --workspace @alehdezp/rooklight-shell
```

The owning tests are [index.test.mjs](index.test.mjs) and [install-lean-ctx.test.mjs](install-lean-ctx.test.mjs).
